//
//  ContentView.swift
//  Test
//
//  Created by APPLE on 2020/03/18.
//  Copyright © 2020 APPLE. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var fontSize: CGFloat = 25
    
    var body: some View {
        VStack {
            Stepper(value: $fontSize, in: 10 ... 30) {
                Text("Font Size: \(Int(fontSize))").font(.custom("Gill Sans UltraBold", size: 25))
            }.padding()
            List {
                ForEach(AppDelegate.fontNames) { font in
                    Text(font.fontName).font(.custom(font.fontName, size: self.fontSize))
                }
            }
        }

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
