//
//  FontNames.swift
//  Test
//
//  Created by APPLE on 2020/03/18.
//  Copyright © 2020 APPLE. All rights reserved.
//

import Foundation

struct FontNames: Identifiable {
    var id = UUID()
    var fontName: String
}
